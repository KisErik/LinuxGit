/*** A header file for symbolic boolean type ***/

typedef enum bool {false, true} boolean;



