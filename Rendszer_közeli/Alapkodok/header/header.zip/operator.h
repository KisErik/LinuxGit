/*** Boolean operators ***/

#ifndef boolean
  #include "boolean.h"
#endif

#define not !
#define and &&
#define or  ||
